/**
 * System configuration for Angular 2 samples
 * Adjust as necessary for your application needs.
 */
(function (global) {

    var map = {}, packages = {}, paths = {}, bundles = {}, meta = {}, paths = {};;

    var ngPackageNames = [
        'common',
        'compiler',
        'core',
        'forms',
        'http',
        'platform-browser',
        'platform-browser-dynamic',
        'router',
        'forms'
    ];

    meta['reflect-decorators/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/reflect-decorators/0.1.3-ms1'
        }
    };

    meta['zone.js/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/zone.js/0.6.25-ms1'
        }
    };
    
    meta['core-js/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/core-js/2.4.1'
        }
    };

    meta['moment'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/moment.js/2.17.1'
        }
    };

    meta['app/*'] = {
        format: 'register',
        scriptLoad: true
    };
    packages['app'] = { main: 'main.app', defaultExtension: 'js' }
    map['app'] = 'base/app';

    // This should be the toolkits proxy once it is available there
    var angular2URI = Module.resolve("ria", "angular.js", "2.4.7")
        .replace(/\/\/(.*).ms.com\//, function (match, g1) { return '/' + g1 + '/'; })
        .replace(/http:/, '')
        + '/@angular';

    meta[angular2URI + "/*"] = {
        format: 'amd',
        deps: [
            'ms/ria/zone.js/0.6.25-ms1',
            'ms/ria/reflect-decorators/0.1.3-ms1'
        ]
    };
    map['@angular'] = angular2URI;
    ngPackageNames.forEach(function (pkgName) {
        packages['@angular/' + pkgName] = { main: 'bundles/' + pkgName + '.umd.js' };
    });
    ngPackageNames.forEach(function (pkgName) {
        meta['@angular/' + pkgName + '/testing'] = { scriptLoad: true }
        packages['@angular/' + pkgName + '/testing'] = { defaultExtension: 'js', format: 'amd' };
        map['@angular/' + pkgName + '/testing'] = angular2URI + '/' + pkgName + '/bundles/' + pkgName + '-testing.umd.js';
    });

    meta['rxjs/*'] = { scriptLoad: true }
    packages['rxjs'] = { defaultExtension: 'js', format: 'amd' };
    var rxjsURI = Module.resolve('ria', 'rxjs', '5.1.0') + '/amd';
    map['rxjs'] = rxjsURI;

    meta['zone/*'] = { scriptLoad: true }
    packages['zone'] = { defaultExtension: 'js', format: 'amd' };
    var zoneURI = Module.resolve('ria', 'zone.js', '0.6.25-ms1') + '/dist';
    map['zone'] = zoneURI;

    /**
     * Add here the configuration for new libraries:
     * 
     * meta['library-name'] = {
     *   format: 'amd',
     *   scriptLoad: true
     * };
     * map['library-name'] = Module.resolve("library-meta", "library-name", "library-version") + '/path/to/js/file.js';
     *
     * Don't forget to also add the library in the following files:
     * - systemjs.boostrap.js
     * - systemjs.spec.boostrap.js
     * - systemjs.config.js
     * - Gruntfile.js
     */

    var config = {
        msOptions: {
            shim: {}
        },
        meta: meta,
        map: map,
        paths: paths,
        packages: packages
    }

    System.config(config);
})(this);

