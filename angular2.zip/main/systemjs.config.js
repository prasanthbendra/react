
/**
 * System configuration for Angular 2 samples
 * Adjust as necessary for your application needs.
 * 
 * These files have the following use:
 *
 * - **systemjs.bootstrap.js** - Imports the libraries and modules in the correct order
 * - **systemsjs.config.js** - Angular 2 config file
 * - **systemjs.spec.bootstrap.js** - Imports the libraries and modules in the correct order when testing using Karma
 * - **systemsjs.config.js** - Angular 2 config file when testing using Karma
 * - **build.override** - Stops System.js removing script tags during webaurora-concat
 *
 */

(function (global) {

    var map = {}, packages = {}, paths = {}, bundles = {}, meta = {};

    // This is used here to set up packages and in systemjs.bootstrap.js to force load ng2 in the correct order
    global.ngPackageNames = [
        'core',
        'compiler',
        'common',
        'forms',
        'http',
        'platform-browser',
        'platform-browser-dynamic',
        'router',
        'forms'
    ];

    meta['*'] = {
        scriptLoad: true,
    };

    meta['zone.js/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/zone.js/0.6.25-ms1'
        }
    };

    meta['reflect-decorators/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/reflect-decorators/0.1.3-ms1'
        }
    };

    meta['core-js/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/core-js/2.4.1'
        }
    };

   /* meta['moment'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/moment.js/2.10.6'
        }
    };*/


    meta['app/*'] = {
        format: 'register'
    };
    packages['app'] = { main: 'main', defaultExtension: 'js' };

    if (!Module.isPreCompiled()) {
        var angular2URI = Module.resolve("ria", "angular.js", "2.4.7") + '/@angular';
        meta[angular2URI + "/*"] = {
            format: 'amd',
            deps: [
                'ms/ria/zone.js/0.6.25-ms1',
                'ms/ria/reflect-decorators/0.1.3-ms1'
            ]
        };
        map['@angular'] = angular2URI;
        ngPackageNames.forEach(function (pkgName) {
            packages['@angular/' + pkgName] = { main: 'bundles/' + pkgName + '.umd.js' };
        });

        // Rxjs loading before concatenation
        var rxjsURI = Module.resolve('ria', 'rxjs', '5.1.0') + '/amd';
        packages['rxjs'] = { defaultExtension: 'js', format: 'amd' };
        map['rxjs'] = rxjsURI;

        var loadashURI = Module.resolve("ria", "lodash", "4.16.4") + '/dist/lodash.js';
        packages['lodash'] = { defaultExtension: 'js', format: 'amd'};
        map['lodash'] = loadashURI;

        var momentURI = Module.resolve("ria", "moment.js", "2.17.1") + '/common/moment.js';
        packages['moment'] = { defaultExtension: 'js', format: 'amd'};
        map['moment'] = momentURI;
        
        /**
         * Add here the configuration for new libraries:
         * 
         * meta['library-name'] = {
         *   format: 'amd',
         *   scriptLoad: true
         * };
         * paths['library-name'] = Module.resolve("library-meta", "library-name", "library-version") + '/path/to/js/file.js';
         *
         * Don't forget to also add the library in the following files:
         * - systemjs.boostrap.js
         * - systemjs.spec.boostrap.js
         * - systemjs.spec.config.js
         * - Gruntfile.js
         */
    }

    System.config({
        msOptions: {
            shim: {}
        },
        meta: meta,
        map: map,
        paths: paths,
        packages: packages,
        bundles: bundles
    });
})(this);