//Do not modify this file, only if you need to import additional libraries. If that is the case follow the instructions below.
(function () {
    //Bootstrapping load
    var karmaLoadedFunction = window.__karma__.loaded;
    window.__karma__.loaded = function () { };
    Module.debugMode();
    Promise.resolve()
        .then(function () {
            return System.import('core-js/main');
        })
        .then(function () {
            return Promise.all([
                System.import('zone.js/main'),
                Module.load('ria', 'moment', '2.17.1')/*,
                Module.load('ria', 'ng2-bootstrap', '1.1.13'),
                Module.load('msjs', 'bootstrap-theme', '2016.08.18-1', 'msdark')
                /**
                 * Load here additional libraries required. 
                 * System.import('module-name')
                 *
                 * Don't forget to add the library in the following files:
                 * - systemjs.boostrap.js
                 * - systemjs.config.js
                 * - systemjs.spec.config.js
                 * - Gruntfile.js
                 */
            ]);
        }).then(function () {
            return Promise.all([
                System.import('zone/proxy'),
                System.import('zone/wtf'),
                System.import('zone/long-stack-trace-zone'),
                System.import('zone/sync-test'),
                System.import('zone/task-tracking'),
                System.import('zone/async-test'),
                System.import('zone/fake-async-test')
            ]);
        }).then(function () {
            return Promise.all([
                System.import('zone/jasmine-patch')
            ]);
        }).then(function () {
            function isSpecFile(path) {
                return path.slice(-8) === '.spec.js';
            }
            return Promise.all(
                Object.keys(window.__karma__.files).filter(isSpecFile).map(function (moduleName) {
                    return System.import(moduleName);
                })
            );
        }).then(function () {
            window.__karma__.loaded = karmaLoadedFunction;
            window.__karma__.loaded();
        }).catch(function (error) {
            console.error(error.message);
            console.error(error.stack);
        });

})();