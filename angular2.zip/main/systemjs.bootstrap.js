(function (global) {
    /**
     * Notice the chain of Promises, the order in which we load the libraries does matter.
     */
    Promise.resolve()
        .then(function () {
            return System.import('core-js/main');
        })
        .then(function () {
            return Promise.all([
                    System.import('zone.js/main'),
                    Module.load('ria', 'moment.js', '2.17.1')
                    //Module.load('ria', 'lodash', '4.16.4')
                 /*,
                Module.load('ria', 'ng2-bootstrap', '1.1.13'),
                /* Load here additional libraries required. 
                * System.import('module-name')
                *
                * Don't forget to add the library in the following files:
                * - systemjs.config.js
                * - systemjs.spec.boostrap.js
                * - systemjs.spec.config.js
                * - Gruntfile.js
                */
            ]);
        }).then(function () {
            // All the AngularJS files need to be resolved before importing the application files.
            return Promise.all(window.ngPackageNames.map(function (pkgName) { return System.import('@angular/' + pkgName); }));
        }).then(function () {
            // Load the application once the dependencies have been resolved, but only when not running WebAurora Concat (this
            // prevents the application resources from being concatenated which is necessary at the moment due to problems with
            // SystemJS running correctly within the concatenated code).
            if (!global.__isRunningWebAuroraConcat) {
                return System.import('app');
            }
        }).catch(function (err) {
            console.error(err);
        });
})(this);