import { ModuleWithProviders } from '@angular/core';

import { HomeModule } from './home/home.module';
import { UserModule } from './user/user.module';
import { TestModule } from './test/test.module';
import { FormModule } from './form/form.module';
import { ChangeDetectionModule } from './change-detection/change-detection.module';

export const featureModules: Array<any> = [
  HomeModule,
  UserModule, 
  TestModule,
  FormModule,
  ChangeDetectionModule
];
