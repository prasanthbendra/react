import { NgModule } from '@angular/core';
import {RouterModule, Routes, PreloadAllModules} from '@angular/router';

import { SelectivePreloadingStrategy } from './core/selective-preloading-strategy';

import { ComposeMessageComponent } from './compose-message.component';

const appRoutes: Routes = [
    { path: 'about', data: { preload: true }, loadChildren: './app/about/about.module#AboutModule' },
    { path: 'admin', loadChildren: './app/admin/admin.module#AdminModule' },
    { path: 'compose', component: ComposeMessageComponent, outlet: 'popup' },
    { path: '', redirectTo: '/change-detection', pathMatch: 'full' },
    { path: '**', redirectTo: '/change-detection', pathMatch: 'full' }
];

@NgModule({
  imports: [ RouterModule.forRoot(appRoutes, { preloadingStrategy: SelectivePreloadingStrategy }) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {

}

