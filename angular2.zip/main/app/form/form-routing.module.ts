import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FormComponent } from './form.component';
import { FormUserInputComponent } from './form-user-input.component';
import { FormTemplateDrivenComponent } from './form-template-driven.component';
import { FormReactiveComponent } from './form-reactive.component';

const formRoutes: Routes = [
  { 
    path: 'form', 
    component: FormComponent,
    children: [
      { path: '', component: FormTemplateDrivenComponent }, 
      { path: 'user-inputs', component: FormUserInputComponent }, 
      { path: 'template-driven', component: FormTemplateDrivenComponent }, 
      { path: 'reactive', component: FormReactiveComponent }, 
    ] 
  }
];

@NgModule({
  imports: [ RouterModule.forChild( formRoutes ) ],
  exports: [ RouterModule ]
})
export class FormRoutingModule {

}
