import { Component, ViewChild, AfterViewChecked } from '@angular/core';
import { NgForm } from '@angular/forms';

import { User } from './user'; 

@Component({
  selector: 'nao-form-template-driven',
  templateUrl: './app/form/form-template-driven.component.html',
  styles: [ `
    .ng-valid[required], .ng-valid.required {
      border-left: 5px solid green;
    } 
    .ng-invalid:not(form){
      border-left: 5px solid red; 
    }
    .template-form{ 
      margin-left: 30px; 
    }
  ` ]
})
export class FormTemplateDrivenComponent implements AfterViewChecked {
  userForm: NgForm;
  @ViewChild('userForm') currentForm: NgForm;

  ngAfterViewChecked(){
    this.formChanged(); 
  }
  
  options = [
    'Option1', 
    'Option2', 
    'Option3', 
    'Option4' 
  ];

  formErrors = {
    'name': '',
    'email': '' 
  }

  validationMessages = {
    'name': {
      'required': 'Name is required.',
      'minlength': 'Name must be at least 4 characters long.',
      'maxlength': 'Name cannot be more than 24 characters long.',
    },
    'email': {
      'required': 'email is required'
    }
  };
  
  user = new User( 1, 'Prasanth', 'prasanthbendra@gmail.com', this.options[0], 'Banglore' );

  onSubmit(){
    console.log('submitted'); 
  }

  formChanged(){
    if(this.userForm === this.currentForm){ return; } 
    this.userForm = this.currentForm;
    if(this.userForm){
      this.userForm.valueChanges
        .subscribe(data => this.onValueChanged(data));
    }
  }

  onValueChanged(data?: any) {
    if (!this.userForm) { return; }
    const form = this.userForm.form;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
          for (const key in control.errors) {
            this.formErrors[field] += messages[key] + ' ';
          }
      }
    }
  }

}
