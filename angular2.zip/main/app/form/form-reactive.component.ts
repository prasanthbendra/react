import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'nao-form-reactive',
  templateUrl: './app/form/form-reactive.component.html',
  styles: [
    `
      .reactive-form {
        margin-left: 30px 
      } 
    ` 
  ]
})
export class FormReactiveComponent {
  userForm: FormGroup;

  constructor(private fb: FormBuilder){
    this.createForm(); 
  }

  createForm(){
    this.userForm = this.fb.group({
      name: [ '', Validators.required ],
      address: this.fb.group({
        street: '',
        city: '',
        state: '',
        zip: ''
      })
    }); 
  }
}
