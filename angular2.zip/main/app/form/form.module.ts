import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';

import { FormRoutingModule } from './form-routing.module';
import { FormComponent } from './form.component';
import { FormUserInputComponent } from './form-user-input.component';
import { FormTemplateDrivenComponent } from './form-template-driven.component';
import { FormReactiveComponent } from './form-reactive.component';

@NgModule({
  imports: [ SharedModule, FormRoutingModule ],
  declarations: [ 
    FormComponent,
    FormUserInputComponent,
    FormTemplateDrivenComponent,
    FormReactiveComponent
  ]
})
export class FormModule {

}
