export class User {
  id = 0;
  name = '';
  address: Address[]
}

export class Address {
  street = '';
  city = '';
  state = '';
  zip = '';
}

export const states = [ 'KL', 'KA', 'TN', 'MH', 'AP' ];

export const users: User[] = [
  {
    id: 1,
    name: 'Prasanth Bendra',
    address: [
      {
        street: '123, Street',
        city: 'Banglore',
        state: 'Karnataka',
        zip: '123456'
      }, 
      {
        street: '123, Street',
        city: 'Banglore',
        state: 'Karnataka',
        zip: '123456'
      } 
    ]
  },{
    id: 2,
    name: 'John Doe',
    address: [
      {
        street: '123, Street',
        city: 'Banglore',
        state: 'Karnataka',
        zip: '123456'
      }, 
      {
        street: '123, Street',
        city: 'Banglore',
        state: 'Karnataka',
        zip: '123456'
      } 
    ]
  }

];
