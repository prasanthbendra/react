import { Component } from '@angular/core';

@Component({
  selector: 'nao-form-user-input',
  templateUrl: './app/form/form-user-input.component.html'
})
export class FormUserInputComponent {

  value: string = "";
  keyvalue: string = "";

  onClickMe(){
    this.value = 'Prasanth Bendra'; 
  }

  onKey( value: string ){
    this.keyvalue += value + ' | '; 
  }


}
