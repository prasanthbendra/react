import { Component } from '@angular/core';

@Component({
  selector: 'nao-form',
  templateUrl: './app/form/form.component.html'
})
export class FormComponent {

}
