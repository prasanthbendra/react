import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';

import { AboutRoutingModule } from './about-routing.module';
import { AboutComponent } from './about.component';
import { AboutDetailComponent } from './about-detail.component';

import { AboutService } from './about.service';
import { AboutBetterService } from './about-better.service';

import { AboutAnotherService } from './about.token';

@NgModule({
  imports: [ 
    SharedModule, 
    AboutRoutingModule
  ],
  declarations: [ AboutComponent, AboutDetailComponent ],
  providers: [ 
    { provide: AboutService, useClass: AboutBetterService },
    { provide: AboutAnotherService, useValue: 'AboutService' }
  ]
})
export class AboutModule {
}
