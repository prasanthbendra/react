import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'nao-about-detail',  
  templateUrl: './app/about/about-detail.component.html'
})
export class AboutDetailComponent implements OnInit {
  constructor( private route: ActivatedRoute, private router: Router ){
    
  }

  ngOnInit(){
    let id = this.route.snapshot.params['id'];
    console.log(id);

    this.route.params   
      .subscribe( (params: Params) => { console.log(params); } );
  }

  onClick(){
      this.router.navigate(['/about', Math.floor( Math.random() * 100 ), { test: 'testtest', foo: 'fooo' }]); 
  }
}
