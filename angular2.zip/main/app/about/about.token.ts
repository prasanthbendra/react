import { OpaqueToken } from '@angular/core';

export const AboutAnotherService = new OpaqueToken('AboutAnotherService');
