import { Injectable } from '@angular/core';

@Injectable()
export class AboutBetterService{
  getData(){
    let text = `Hi Prasanth Bendra`; 
    return text;
  }
}
