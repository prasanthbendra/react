import { Injectable } from '@angular/core';

@Injectable()
export class AboutService{
  getData(){
    let text = `Hi there`; 
    return text;
  }
}
