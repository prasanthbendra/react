import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';

import { AboutService } from './about.service';
import { AboutAnotherService } from './about.token';

@Component({
  selector: 'nao-about',
  templateUrl: './app/about/about.component.html' 
})

export class AboutComponent {
  aboutText: string;
  show: boolean = false;
  
  constructor( private router: Router, @Inject(AboutAnotherService) private testVal: string ){
    this.aboutText = testVal;  
  }

  onClick(){
    this.router.navigate(['/about', Math.floor( Math.random() * 100 ), { test: 'test' }]); 
  }
  
  toggleShow(){
    this.show = !this.show; 
  }
  
  canDeactivate(){
    return confirm('Do you want to leave the page?'); 
  }

}
