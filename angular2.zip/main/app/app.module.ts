import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { ComposeMessageComponent } from './compose-message.component';

import { CoreModule } from './core/core.module';
import { featureModules } from './feature-modules'; 

@NgModule({
    declarations: [ AppComponent, ComposeMessageComponent  ],
    imports: [
        BrowserModule,
        ...featureModules, 
        CoreModule.forRoot( { name: 'Bendra', city: 'Cochin' } ),
        AppRoutingModule 
    ],
    bootstrap: [ AppComponent ]
})

export class AppModule {
  constructor( private router: Router ){
    // console.log( 'Routes: ' + JSON.stringify( router.config, undefined, 2 ) ); 
  }
}
