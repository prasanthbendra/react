import { 
  Component, 
  Input, 
  OnChanges, 
  OnInit, 
  DoCheck, 
  AfterContentInit,
  AfterContentChecked,
  AfterViewInit,
  AfterViewChecked,
  OnDestroy 
} from '@angular/core';

@Component({
  selector: 'nao-user-content-child',
  templateUrl: './app/user/user-content-child.component.html'
})
export class UserContentChildComponent implements OnInit, OnDestroy, DoCheck, OnChanges {

  constructor(){
    // console.log('  Input variable test: ', this.test);
    console.log('%c  >> Constructor: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngOnChanges(){
    console.log('%c  >> OnChanges: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngOnInit(){
    console.log('%c  >> OnInit: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngDoCheck(){
    console.log('%c  >> DoCheck: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngAfterContentInit(){
    console.log('%c  >> AfterContentInit: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }
  
  ngAfterContentChecked(){
    console.log('%c  >> AfterContentChecked: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }
  
  ngAfterViewInit(){
    console.log('%c  >> AfterViewInit: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngAfterViewChecked(){
    console.log('%c  >> AfterViewChecked: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

  ngOnDestroy(){
    console.log('%c  >> OnDestroy: UserContentChild', 'background: #9f7ade; color: #fff'); 
  }

}
