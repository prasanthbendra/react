import { Component } from '@angular/core';

@Component({
  selector: 'nao-user-test',
  templateUrl: './app/user/user-test.component.html'
})
export class UserTestComponent {

}
