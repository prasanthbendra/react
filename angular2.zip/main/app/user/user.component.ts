import { 
  Component, 
  Optional,
  OnInit,
  OnDestroy,
  DoCheck,
  OnChanges,
  AfterViewInit,
  AfterViewChecked,
  AfterContentInit,
  AfterContentChecked
} from '@angular/core';

import { AboutService } from '../about/about.service'; 

@Component({
  selector: 'nao-user',
  templateUrl: './app/user/user.component.html' 
})

export class UserComponent {
  test: Date = new Date();
  constructor( @Optional() private aboutService: AboutService ){
    aboutService ?  console.log(aboutService.getData()) : '' ;  
    console.log('Constructor: Parent');
  }

  ngOnChanges(){
    console.log('ngOnChanges: Parent'); 
  }

  ngOnInit(){
    console.log('ngOnInit: Parent'); 
  }

  ngDoCheck(){
    console.log('ngDocheck: Parent'); 
  }

  ngAfterContentInit(){
    console.log('ngAfterContentInit: Parent'); 
  }

  ngAfterContentChecked(){
    console.log('ngAfterContentChecked: Parent'); 
  }

  ngAfterViewInit(){
    console.log('ngAfterViewInit: Parent'); 
  }

  ngAfterViewChecked(){
    console.log('ngAfterViewChwcked: Parent'); 
  }

  changeString(){
    this.test = new Date(); 
  }
}
