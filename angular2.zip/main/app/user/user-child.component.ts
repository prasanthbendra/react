import { 
  Component, 
  Input, 
  OnInit, 
  OnDestroy, 
  DoCheck, 
  OnChanges 
} from '@angular/core';

@Component({
  selector: 'nao-user-child',
  templateUrl: './app/user/user-child.component.html'
})
export class UserChildComponent implements OnInit, OnDestroy, DoCheck, OnChanges {
  @Input() test: Date;

  constructor(){
    // console.log('  Input variable test: ', this.test);
    console.log('%c  Constructor: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngOnChanges(){
    console.log('%c  OnChanges: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngOnInit(){
    console.log('%c  OnInit: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngDoCheck(){
    console.log('%c  DoCheck: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngAfterContentInit(){
    console.log('%c  AfterContentInit: UserChild', 'background: #fab6b7; color: #fff'); 
  }
  
  ngAfterContentChecked(){
    console.log('%c  AfterContentChecked: UserChild', 'background: #fab6b7; color: #fff'); 
  }
  
  ngAfterViewInit(){
    console.log('%c  AfterViewInit: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngAfterViewChecked(){
    console.log('%c  AfterViewChecked: UserChild', 'background: #fab6b7; color: #fff'); 
  }

  ngOnDestroy(){
    console.log('%c  OnDestroy: UserChild', 'background: #fab6b7; color: #fff'); 
  }

}
