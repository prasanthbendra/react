import { 
  Component, 
  Input, 
  OnInit, 
  OnDestroy, 
  DoCheck, 
  OnChanges 
} from '@angular/core';

@Component({
  selector: 'nao-user-content',
  templateUrl: './app/user/user-content.component.html'
})
export class UserContentComponent implements OnInit, OnDestroy, DoCheck, OnChanges {
  @Input() test: Date;

  constructor(){
    // console.log('  Input variable test: ', this.test);
    console.log('%c  >>Constructor: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngOnChanges(){
    console.log('%c  >>OnChanges: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngOnInit(){
    console.log('%c  >>OnInit: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngDoCheck(){
    console.log('%c  >>DoCheck: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngAfterContentInit(){
    console.log('%c  >>AfterContentInit: UserContent', 'background: #42e2a8; color: #fff'); 
  }
  
  ngAfterContentChecked(){
    console.log('%c  >>AfterContentChecked: UserContent', 'background: #42e2a8; color: #fff'); 
  }
  
  ngAfterViewInit(){
    console.log('%c  >>AfterViewInit: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngAfterViewChecked(){
    console.log('%c  >>AfterViewChecked: UserContent', 'background: #42e2a8; color: #fff'); 
  }

  ngOnDestroy(){
    console.log('%c  >>OnDestroy: UserContent', 'background: #42e2a8; color: #fff'); 
  }

}
