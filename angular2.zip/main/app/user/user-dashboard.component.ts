import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'nao-user-dashboard',
  templateUrl: './app/user/user-dashboard.component.html'
})
export class UserDashboardComponent {
  constructor( private route: ActivatedRoute, private router: Router ){
  
  }

  changeRoute(){
    this.router.navigate( ['test'], {relativeTo: this.route} ) 
  }

  userRoute(){
    this.router.navigate( ['./'], {relativeTo: this.route} ); 
  }
}
