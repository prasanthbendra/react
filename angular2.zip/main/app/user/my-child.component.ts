import { 
  Component, 
  Input, 
  OnInit, 
  OnDestroy, 
  DoCheck, 
  OnChanges,
  AfterContentInit,
  AfterContentChecked,
  AfterViewInit,
  AfterViewChecked
} from '@angular/core';

@Component({
  selector: 'nao-my-child',
  templateUrl: './app/user/my-child.component.html'
})
export class MyChildComponent implements OnInit, OnDestroy, DoCheck, OnChanges {
  @Input() test: Date;

  constructor(){
    // console.log('  Input variable test: ', this.test);
    console.log('%c  Constructor: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngOnChanges(){
    console.log('%c  OnChanges: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngOnInit(){
    console.log('%c  OnInit: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngDoCheck(){
    console.log('%c  DoCheck: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngAfterContentInit(){
    console.log('%c  AfterContentInit: MyChild', 'background: #ffd500; color: #fff'); 
  }
  
  ngAfterContentChecked(){
    console.log('%c  AfterContentChecked: MyChild', 'background: #ffd500; color: #fff'); 
  }
  
  ngAfterViewInit(){
    console.log('%c  AfterViewInit: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngAfterViewChecked(){
    console.log('%c  AfterViewChecked: MyChild', 'background: #ffd500; color: #fff'); 
  }

  ngOnDestroy(){
    console.log('%c  OnDestroy: MyChild', 'background: #ffd500; color: #fff'); 
  }

}
