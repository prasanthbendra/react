import { NgModule } from '@angular/core';

import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { UserDashboardComponent } from './user-dashboard.component';
import { UserTestComponent } from './user-test.component';
import { UserChildComponent } from './user-child.component';
import { UserContentComponent } from './user-content.component';
import { UserContentChildComponent } from './user-content-child.component';
import { MyChildComponent } from './my-child.component';

@NgModule({
  imports: [ UserRoutingModule ],
  declarations: [ 
    UserComponent, 
    UserDashboardComponent, 
    UserTestComponent,
    UserChildComponent,
    UserContentComponent,
    UserContentChildComponent,
    MyChildComponent
  ]
})
export class UserModule {

}
