import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserComponent } from './user.component';
import { UserDashboardComponent } from './user-dashboard.component';
import { UserTestComponent } from './user-test.component';

const userRoutes: Routes = [
  { 
    path: 'user', 
    component: UserComponent, 
    children: [
      {
        path: 'test',
        component: UserTestComponent
      }, 
      {
        path: '',
        component: UserDashboardComponent
      }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild(userRoutes) ],
  exports: [ RouterModule ]
})
export class UserRoutingModule {

}
