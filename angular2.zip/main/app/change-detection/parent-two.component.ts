import { Component, DoCheck, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'parent-two',
  templateUrl: './app/change-detection/parent-two.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParentTwoComponent implements DoCheck {
  ngDoCheck(){
    console.log( '%c Change detection in Parent two', 'color: #FFFFFF; background-color: #000000' ); 
  }
}
