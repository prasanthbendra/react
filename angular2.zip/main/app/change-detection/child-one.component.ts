import { Component, Input, OnChanges, DoCheck } from '@angular/core';

@Component({
  selector: 'child-one',
  templateUrl: './app/change-detection/child-one.component.html'
})
export class ChildOneComponent implements OnChanges, DoCheck {

  @Input() testVar;

  ngOnChanges(){
    console.log(this.testVar); 
  }

  ngDoCheck(){
    console.log( '%c Change detection in child one', 'color: #FFFFFF; background-color: #e2bace' ); 
  }
}
