import { NgModule } from '@angular/core';

import { ChangeDetectionRoutingModule } from './change-detection-routing.module';
import { ChangeDetectionComponent } from './change-detection.component';
import { ChildComponent } from './child.component';
import { ParentOneComponent } from './parent-one.component';
import { ParentTwoComponent } from './parent-two.component';
import { ChildOneComponent } from './child-one.component';
import { ChildTwoComponent } from './child-two.component';

@NgModule({
  imports: [ ChangeDetectionRoutingModule ],
  declarations: [ 
    ChangeDetectionComponent, 
    ChildComponent,
    ParentOneComponent,
    ParentTwoComponent,
    ChildOneComponent,
    ChildTwoComponent
  ]
})
export class ChangeDetectionModule {

}
