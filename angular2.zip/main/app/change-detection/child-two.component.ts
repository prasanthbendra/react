import { Component, DoCheck } from '@angular/core';

@Component({
  selector: 'child-two',
  templateUrl: './app/change-detection/child-two.component.html'
})
export class ChildTwoComponent implements DoCheck {

  ngDoCheck(){
    console.log( '%c Change detection in child two', 'color: #FFFFFF; background-color: #cccccc' ); 
  }

  fnTwo(){
    console.log('click two'); 
  }
  
}
