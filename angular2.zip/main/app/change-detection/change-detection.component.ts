import { Component, DoCheck } from '@angular/core';

@Component({
  selector: 'nao-change-detection',
  templateUrl: './app/change-detection/change-detection.component.html'
})
export class ChangeDetectionComponent implements DoCheck {
  testVar = {name: 'prasanth'};

  ngDoCheck(){
    // console.log('%c Change detection in Parent component', 'color: #FFFFFF; background-color: #00FF00') 
  }

  changeVariable(){
    this.testVar.name = 'New value'; 
  }

  anotherClick(){
    console.log('Clicked') 
  }
}
