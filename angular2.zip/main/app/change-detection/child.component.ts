import { 
  Component, 
  ChangeDetectionStrategy, 
  Input, 
  OnInit, 
  DoCheck, 
  OnChanges 
} from '@angular/core';

@Component({
  selector: 'childo',
  templateUrl: './app/change-detection/child.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChildComponent implements OnInit {

  @Input() test;

  ngOnChanges(){
    // console.log('Child input changed'); 
  }
  
  ngOnInit(){
    // console.log(this.test); 
  }

  ngDoCheck(){
    // console.log(this.test);
    // console.log('%c Change detection in Child component', 'color: #FFFFFF; background-color: #FF0000') 
  }

}
