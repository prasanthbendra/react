import { 
  Component, 
  DoCheck, 
  ChangeDetectionStrategy,
  NgZone,
  ChangeDetectorRef
} from '@angular/core';

@Component({
  selector: 'parent-one',
  templateUrl: './app/change-detection/parent-one.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParentOneComponent implements DoCheck {
  
  parentVar = "test value";

  constructor(
    private ngZone: NgZone, 
    private changeDetectorRef: ChangeDetectorRef 
  ){
  
  }

  ngDoCheck(){
    console.log( '%c Change detection in parent one', 'color: #FFFFFF; background-color: #e5446d' ) 
  }

  changeValue(){
    this.parentVar = "Prasanth Bendra"; 
  }

}
