import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ChangeDetectionComponent } from './change-detection.component'

const changeDetectionRoutes: Routes = [
  { path: 'change-detection', component: ChangeDetectionComponent }
];

@NgModule({
  imports: [ RouterModule.forChild( changeDetectionRoutes ) ],
  exports: [ RouterModule ]
})
export class ChangeDetectionRoutingModule {

}
