import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { BannerOne } from './bannerone/banner-one.component';
import { BannerTwo } from './bannertwo/banner-two.component';
import { BannerThree } from './bannerthree/banner-three.component';
import { BannerFour } from './bannerfour/banner-four.component';
import { AdDirective } from './bannerone/ad.directive';
import { LoadOneComponent } from './bannerone/load-one.component';

@NgModule({
  imports: [ 
    SharedModule, 
    HomeRoutingModule 
  ],
  declarations: [ 
    HomeComponent,
    AdDirective,
    BannerOne,
    BannerTwo,
    BannerThree,
    BannerFour,
    LoadOneComponent
  ],
  entryComponents: [
    LoadOneComponent 
  ]
})

export class HomeModule {

}
