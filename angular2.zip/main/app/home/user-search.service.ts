import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';

@Injectable()
export class UserSearchService {

  /* options = new RequestOptions({
    headers: new Headers({
      'test': 'test' 
    }) 
  }) */

  private apiUrl = '/api/users';
  constructor( private http: Http, private options: RequestOptions ){
    options.headers.append('new-header', 'testesteststes')
  }

  search( term ){
    const url = `${this.apiUrl}/?name=${term}`;
    return this.http.get( url )
      .map( response => response.json() )
  }

  test(){
    const url = '/api/test'; 
    return this.http.get( url, this.options ) 
      .map( response => response.json() )
      .map( response => response.data )
      .share();
  }
}
