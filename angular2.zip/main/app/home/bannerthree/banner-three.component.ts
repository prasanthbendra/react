import { Component } from '@angular/core';

@Component({
  selector: 'banner-three',
  templateUrl: './app/home/bannerthree/banner-three.component.html'
})
export class BannerThree {

}

