import { Component, AfterViewInit, ViewChild, ComponentFactoryResolver } from '@angular/core';

import { AdDirective } from './ad.directive'; 
import { LoadOneComponent } from './load-one.component';

@Component({
  selector: 'banner-one',
  templateUrl: './app/home/bannerone/banner-one.component.html'
})
export class BannerOne implements AfterViewInit {
  @ViewChild(AdDirective) adHost: AdDirective;

  constructor( private componentFactoryResolver: ComponentFactoryResolver ){
  
  }

  ngAfterViewInit(){
    this.loadComponent(); 
  }

  loadComponent(){
    let componentFactory = this.componentFactoryResolver.resolveComponentFactory( LoadOneComponent );
    let viewContainerRef = this.adHost.viewContainerRef;
    viewContainerRef.clear();
    viewContainerRef.createComponent( componentFactory );
  }
}
