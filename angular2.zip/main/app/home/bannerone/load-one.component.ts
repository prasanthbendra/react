import { Component } from '@angular/core';

@Component({
  templateUrl: './app/home/bannerone/load-one.component.html'
})
export class LoadOneComponent {

}
