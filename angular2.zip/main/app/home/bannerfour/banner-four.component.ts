import { Component } from '@angular/core';

@Component({
  selector: 'banner-four',
  templateUrl: './app/home/bannerfour/banner-four.component.html'
})
export class BannerFour {

}
