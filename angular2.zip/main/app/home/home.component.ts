import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/observable/of';
import 'rxjs/add/observable/interval';
import 'rxjs/add/observable/forkJoin';

import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/map';

import { UserService } from '../core/user.service';
import { HomeService } from './home.service';
import { UserSearchService } from './user-search.service'; 

@Component({
  selector: 'nao-home',
  templateUrl: './app/home/home.component.html',
  providers: [ HomeService, UserSearchService ]
})

export class HomeComponent {

  show: boolean = false;
  name: string;
  city: string;
  pipevar: string = 'Prasanth';

  private searchTerms = new Subject<string>();

  lists = [
    { name: 'Prasanth', city: 'Banglore' }, 
    { name: 'Test', city: 'Banglore' }, 
    { name: 'Bendra', city: 'Banglore' }, 
    { name: 'John', city: 'Banglore' }, 
    { name: 'Jane', city: 'Banglore' }, 
    { name: 'Prasanth', city: 'Banglore' }, 
  ];

  constructor(
    router: Router, 
    userService: UserService, 
    private homeService: HomeService,
    private userSearchService: UserSearchService,
    private options: RequestOptions
  ){
    // console.log(router); 
    let user = userService.getUser();
    this.name = user.name;
    this.city = user.city;
  }

  ngOnInit(){
    this.searchTerms
      .debounceTime(1000)
      .distinctUntilChanged()
      .switchMap( term => term
        ? this.userSearchService.search(term)
        : Observable.of([])
      )
      .subscribe(
        x => console.log(x) 
      )

    this.homeService.getUsers(10) 
      .then( res => { console.log(res) } )

    this.userSearchService.test()
      .subscribe({
        next: console.log,
        error: console.log,
        complete: () => console.log('Complete')
      })
    
    Observable.forkJoin(this.userSearchService.test(), this.homeService.getUsers(20))
      .subscribe( ([ test, users ]) => { 
        console.log( test ) 
        console.log( users ) 
      })
  }

  changeHeader(){
    this.options.setAuthHeader(); 
  }
  
  toggleShow(){
    this.show = !this.show; 
  }

  search(term){
    this.searchTerms.next(term);
  }
}
