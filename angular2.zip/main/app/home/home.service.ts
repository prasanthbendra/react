import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class HomeService {
  private apiUrl = '/api/users';
  constructor( private http: Http){
  
  }
  
  getUsers( id ){
    const url = `${this.apiUrl}/${id}`;
    return this.http.get(url) 
      .toPromise()
      .then( response => response.json().data )
      .catch( error => { console.log( 'error occured' + error ) } );
  }
}
