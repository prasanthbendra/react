import { Component } from '@angular/core';

@Component({
  selector: 'banner-two',
  templateUrl: './app/home/bannertwo/banner-two.component.html'
})
export class BannerTwo {

}

