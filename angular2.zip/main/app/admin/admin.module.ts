import { NgModule } from '@angular/core';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AdminCrisisComponent } from './admin-crisis.component';
import { AdminHerosComponent } from './admin-heros.component';

@NgModule({
  imports: [ AdminRoutingModule ],
  declarations: [ AdminComponent, AdminCrisisComponent, AdminHerosComponent ]
})
export class AdminModule {

}
