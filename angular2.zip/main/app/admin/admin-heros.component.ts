import { Component } from '@angular/core'; 

@Component({
  selector: 'nao-admin-heros',
  templateUrl: './app/admin/admin-heros.component.html'
})
export class AdminHerosComponent {

}
