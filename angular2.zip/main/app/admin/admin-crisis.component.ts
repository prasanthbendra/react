import { Component } from '@angular/core';

@Component({
  selector: 'nao-admin-crisis',
  templateUrl: './app/admin/admin-crisis.component.html'
})
export class AdminCrisisComponent {

}
