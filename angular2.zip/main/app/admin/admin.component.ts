import { Component } from '@angular/core';

@Component({
  selector: 'nao-admin',
  templateUrl: './app/admin/admin.component.html'
})
export class AdminComponent {

}
