import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminComponent } from './admin.component';
import { AdminCrisisComponent } from './admin-crisis.component';
import { AdminHerosComponent } from './admin-heros.component';

import { AuthGuard } from '../core/auth-guard.service';

const adminRoutes: Routes = [
  { 
    path: '', 
    component: AdminComponent,
    canActivate: [ AuthGuard ],
    children: [
      { 
        path: '',
        children: [
          { path: 'crises', component: AdminCrisisComponent },
          { path: 'heros', component: AdminHerosComponent } 
        ]
      }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild( adminRoutes ) ],
  exports: [ RouterModule ]
})
export class AdminRoutingModule {

}
