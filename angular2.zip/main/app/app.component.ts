import { Component, DoCheck } from '@angular/core';

@Component({
    selector: 'nao-app',
    templateUrl: 'app/app.component.html'
})

export class AppComponent implements DoCheck {

  ngDoCheck(){
    // console.log('%c Change detection in App component', 'color: #FFFFFF; background-color: #0000FF') 
  } 
}
