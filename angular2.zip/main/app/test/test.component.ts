import { Component, ViewChild } from '@angular/core';

import { ChildComponent } from './child.component';

@Component({
  selector: 'nao-test',
  templateUrl: './app/test/test.component.html',
  styles: [ ':host >>> a{ background-color: red; }' ]
})
export class TestComponent {
  @ViewChild( ChildComponent ) private childComponent: ChildComponent;

  parentOne: string;
  parentTwo: Object;
  parentThree: Array<string>;

  constructor(){
    this.parentOne = 'Parent One'; 
    this.parentTwo = {
      name: 'Prasanth',
      city: 'Banglore'
    };
    this.parentThree = [
      'John Doe',
      'Jane Doe',
      'Prasanth Bendra'
    ];
  }

  execChild(){
    this.childComponent.logMessage('WORKING!!!'); 
  }

  testFn(outOne: string){
    this.parentOne = outOne; 
  }  

  parentTest( message ){
    console.log( 'Parent fn: ' + message ); 
  }
}
