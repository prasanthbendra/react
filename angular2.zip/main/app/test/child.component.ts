import { 
  Component, Input, Output, EventEmitter, Inject, forwardRef, ViewEncapsulation 
} from '@angular/core';

import { TestComponent } from './test.component';

@Component({
  selector: 'nao-child',
  templateUrl: './app/test/child.component.html',
  styleUrls: [ './app/test/child.component.css' ],
  encapsulation: ViewEncapsulation.Emulated
})
export class ChildComponent {
  private varOne: string;

  @Input('propOne') 
  set childOne(childOne: string){
    this.varOne = 'ttt ' + childOne;
  }
  get childOne(): string {
    return this.varOne; 
  }

  @Input('propTwo') childTwo;
  @Input('propThree') childThree;

  @Output('onTested') tested = new EventEmitter<string>();

  constructor( @Inject(forwardRef(() => TestComponent)) private testComponent: TestComponent ){
  
  }

  changeObject(){
    this.childTwo.zip = 12345; 
    this.tested.emit('test');
  }

  logMessage( message: string ): void {
    console.log( 'This is a log message ' + message ); 
    this.testComponent.parentTest(message);
  }
}
