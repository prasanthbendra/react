import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';

import { TestRoutingModule } from './test-routing.module';
import { TestComponent } from './test.component';
import { ChildComponent } from './child.component';

@NgModule({
  imports: [ SharedModule, TestRoutingModule ],
  declarations: [ TestComponent, ChildComponent ]
})
export class TestModule {

}
