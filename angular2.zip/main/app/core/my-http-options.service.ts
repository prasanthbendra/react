import { Injectable } from '@angular/core';
import { BaseRequestOptions, Headers, URLSearchParams } from '@angular/http';

@Injectable()
export class MyHttpOptionsService extends BaseRequestOptions {
  constructor(){
    super(); 
    this.headers.append('testeste', 'prasanth bendra')
  }

  setAuthHeader(){
    this.headers.set('testeste', 'bendra')
  }
}
