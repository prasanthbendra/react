import { Injectable, Optional } from '@angular/core';

export class UserServiceConfig {
  name: string = 'Prasanth';
  city: string = 'Banglore';
}

@Injectable()
export class UserService {
  user: UserServiceConfig = {
    name: 'Test', 
    city: 'Test'
  };
  constructor( @Optional() config: UserServiceConfig){
    if( config ) {
      this.user.name = config.name; 
      this.user.city = config.city; 
    }
  }

  getUser(){
    return this.user; 
  }
}
