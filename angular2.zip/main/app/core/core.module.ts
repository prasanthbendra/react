import { NgModule, ModuleWithProviders, Optional, SkipSelf } from '@angular/core';
import { RequestOptions } from '@angular/http';

import { SelectivePreloadingStrategy } from './selective-preloading-strategy';
import { AuthGuard } from './auth-guard.service';
import { CanDeactivateGuard } from './can-deactivate-guard.service';
import { UserService, UserServiceConfig } from './user.service';
import { MyHttpOptionsService } from './my-http-options.service';

@NgModule({
  imports: [],
  exports: [],
  providers: [ 
    AuthGuard, 
    CanDeactivateGuard, 
    SelectivePreloadingStrategy,
    UserService,
    { provide: RequestOptions, useClass: MyHttpOptionsService }
  ],
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule ){
    if( parentModule ){
      throw new Error('Core module is already loaded, Import it only in App module'); 
    }
  }
  
  static forRoot( config: UserServiceConfig ): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [
        { provide: UserServiceConfig, useValue: config } 
      ]
    } 
  }
}
