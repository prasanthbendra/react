import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'nao-compose-message',
  templateUrl: './app/compose-message.component.html'
})

export class ComposeMessageComponent {
  constructor( private router: Router ){
  }
  
  closeContact(){
    this.router.navigate([{outlets: {popup: null}}]); 
  }

}
