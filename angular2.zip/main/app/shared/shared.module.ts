import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { TestPipe } from './test.pipe';
import { HighlightDirective } from './highlight.directive';
import { UnlessDirective } from './unless.directive';

@NgModule({
  imports: [],
  declarations: [ 
    TestPipe, 
    HighlightDirective, 
    UnlessDirective 
  ],
  exports: [
    TestPipe,
    HighlightDirective,
    UnlessDirective,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ]
})
export class SharedModule {

}
