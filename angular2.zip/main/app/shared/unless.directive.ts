import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[myUnless]'
})
export class UnlessDirective {
  private hasView = false;

  constructor( 
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef 
  ){
    //console.log( 'template ref', templateRef );
    //console.log( 'view container', viewContainer );
  }

  @Input() set myUnless( condition: boolean ){
    if( !condition && !this.hasView ){
      this.viewContainer.createEmbeddedView( this.templateRef ); 
      this.hasView = true;
    } else if( condition && this.hasView ){
      this.viewContainer.clear();
      this.hasView = false; 
    } 
  }
}
