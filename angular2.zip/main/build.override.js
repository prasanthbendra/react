(function (global) {
    global.__isRunningWebAuroraConcat = window.navigator.userAgent.match(/PhantomJS/);
    if (global.__isRunningWebAuroraConcat) {
        // No-op head.appendChild to stop System.js removing script tags during webaurora-concat
        var head = document.getElementsByTagName('head')[0];
        if (typeof head != 'undefined') {
            head.removeChild = function (el) { };
        }
        
        // The 'app' element needs to be created when running within webaurora-concat since it wasn't
        // included within the START_REPLACE/END_REPLACE block
        if (document.body) {
            document.body.appendChild(document.createElement('app'));
        }
        else {
            document.addEventListener("DOMContentLoaded", function (event) {
                document.body.appendChild(document.createElement('app'));
            });
        }
    }
})(this);